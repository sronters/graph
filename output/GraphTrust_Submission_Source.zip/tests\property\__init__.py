"""Property-based invariant tests."""
