"""Opt-in performance tests."""
