"""Fast unit tests."""
